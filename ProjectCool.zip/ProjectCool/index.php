<?php

include "functions/functions.php";

?>

<html>

<head>
    <title>Example of an homepage</title>
</head>

<body>
    <!-- the header.php file -->
    <?php
    include "assets/php/header.php"
    ?>

    <!-- the nav.php file -->
    <?php
    include "assets/php/nav.php"
    ?>

    <!-- the index.php file -->
    <div>
        Homepage content
    </div>
</body>

</html>



