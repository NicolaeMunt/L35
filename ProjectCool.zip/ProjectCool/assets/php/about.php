<?php

include("../../functions/functions.php");

?>

<html>

<head>
    <title>About</title>
</head>

<body>
    <!-- the header.php file -->
    <?php
    include "header.php"
    ?>

    <!-- the nav.php file -->
    <?php
    include "nav.php"
    ?>

    <div>
        About page content
    </div>
</body>

</html>



