<?php

include("../../functions/functions.php");

?>

<html>

<head>
    <title>Contact</title>
</head>

<body>
    <!-- the header.php file -->
    <?php
    include "header.php"
    ?>

    <!-- the nav.php file -->
    <?php
    include "nav.php"
    ?>

    <div>
        Contact page content
    </div>
</body>

</html>



